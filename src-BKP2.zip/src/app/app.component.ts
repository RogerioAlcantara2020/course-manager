import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Course-manager';
  name: string = 'Rogerio';
  sobrenome :string ='Alcântara';
}
