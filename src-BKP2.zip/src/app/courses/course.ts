export class Course{
    id: number =0;
    name: string ='';
    imageUrl: string='';
    price: number=0;
    code: string='';
    duration: number=0;
    rating: number = 0;
    description: string| undefined;
    releaseDate: string ='';
}