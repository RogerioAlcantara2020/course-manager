import { Component } from '@angular/core';

@Component({
    templateUrl:'./error-404.component.html'
})
export class Error404Component{

}